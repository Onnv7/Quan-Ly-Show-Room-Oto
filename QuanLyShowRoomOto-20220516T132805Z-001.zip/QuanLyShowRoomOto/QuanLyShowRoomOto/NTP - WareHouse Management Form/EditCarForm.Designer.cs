﻿
namespace QuanLyShowRoomOto
{
    partial class EditCarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.txtGia = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtSoLg = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtNamSX = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtSoGhe = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtMauSac = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtLoai = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtMaXe = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtNhanHieu = new QuanLyShowRoomOto.TextBoxDesign();
			this.btnEdit = new QuanLyShowRoomOto.ButtonDesign();
			this.btnCancel = new QuanLyShowRoomOto.ButtonDesign();
			this.lb_AddNhanHieu = new System.Windows.Forms.Label();
			this.lb_AddSoLg = new System.Windows.Forms.Label();
			this.lb_AddCost = new System.Windows.Forms.Label();
			this.lb_AddColor = new System.Windows.Forms.Label();
			this.lb_AddLoai = new System.Windows.Forms.Label();
			this.lb_AddSoGhe = new System.Windows.Forms.Label();
			this.lb_AddYear = new System.Windows.Forms.Label();
			this.lb_AddMaXe = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtGia
			// 
			this.txtGia.BackColor = System.Drawing.SystemColors.Window;
			this.txtGia.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtGia.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtGia.BorderSize = 2;
			this.txtGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtGia.ForeColor = System.Drawing.Color.Black;
			this.txtGia.Location = new System.Drawing.Point(666, 185);
			this.txtGia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtGia.Multiline = false;
			this.txtGia.Name = "txtGia";
			this.txtGia.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtGia.PasswordChar = false;
			this.txtGia.Size = new System.Drawing.Size(261, 36);
			this.txtGia.TabIndex = 99;
			this.txtGia.Texts = "";
			this.txtGia.UnderlinedStyle = false;
			// 
			// txtSoLg
			// 
			this.txtSoLg.BackColor = System.Drawing.SystemColors.Window;
			this.txtSoLg.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtSoLg.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtSoLg.BorderSize = 2;
			this.txtSoLg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtSoLg.ForeColor = System.Drawing.Color.Black;
			this.txtSoLg.Location = new System.Drawing.Point(666, 241);
			this.txtSoLg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtSoLg.Multiline = false;
			this.txtSoLg.Name = "txtSoLg";
			this.txtSoLg.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtSoLg.PasswordChar = false;
			this.txtSoLg.Size = new System.Drawing.Size(261, 36);
			this.txtSoLg.TabIndex = 98;
			this.txtSoLg.Texts = "";
			this.txtSoLg.UnderlinedStyle = false;
			// 
			// txtNamSX
			// 
			this.txtNamSX.BackColor = System.Drawing.SystemColors.Window;
			this.txtNamSX.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtNamSX.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtNamSX.BorderSize = 2;
			this.txtNamSX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtNamSX.ForeColor = System.Drawing.Color.Black;
			this.txtNamSX.Location = new System.Drawing.Point(666, 73);
			this.txtNamSX.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtNamSX.Multiline = false;
			this.txtNamSX.Name = "txtNamSX";
			this.txtNamSX.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtNamSX.PasswordChar = false;
			this.txtNamSX.Size = new System.Drawing.Size(261, 36);
			this.txtNamSX.TabIndex = 97;
			this.txtNamSX.Texts = "";
			this.txtNamSX.UnderlinedStyle = false;
			// 
			// txtSoGhe
			// 
			this.txtSoGhe.BackColor = System.Drawing.SystemColors.Window;
			this.txtSoGhe.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtSoGhe.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtSoGhe.BorderSize = 2;
			this.txtSoGhe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtSoGhe.ForeColor = System.Drawing.Color.Black;
			this.txtSoGhe.Location = new System.Drawing.Point(666, 129);
			this.txtSoGhe.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtSoGhe.Multiline = false;
			this.txtSoGhe.Name = "txtSoGhe";
			this.txtSoGhe.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtSoGhe.PasswordChar = false;
			this.txtSoGhe.Size = new System.Drawing.Size(261, 36);
			this.txtSoGhe.TabIndex = 96;
			this.txtSoGhe.Texts = "";
			this.txtSoGhe.UnderlinedStyle = false;
			// 
			// txtMauSac
			// 
			this.txtMauSac.BackColor = System.Drawing.SystemColors.Window;
			this.txtMauSac.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtMauSac.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtMauSac.BorderSize = 2;
			this.txtMauSac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtMauSac.ForeColor = System.Drawing.Color.Black;
			this.txtMauSac.Location = new System.Drawing.Point(146, 185);
			this.txtMauSac.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtMauSac.Multiline = false;
			this.txtMauSac.Name = "txtMauSac";
			this.txtMauSac.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtMauSac.PasswordChar = false;
			this.txtMauSac.Size = new System.Drawing.Size(261, 36);
			this.txtMauSac.TabIndex = 95;
			this.txtMauSac.Texts = "";
			this.txtMauSac.UnderlinedStyle = false;
			// 
			// txtLoai
			// 
			this.txtLoai.BackColor = System.Drawing.SystemColors.Window;
			this.txtLoai.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtLoai.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtLoai.BorderSize = 2;
			this.txtLoai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtLoai.ForeColor = System.Drawing.Color.Black;
			this.txtLoai.Location = new System.Drawing.Point(146, 241);
			this.txtLoai.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtLoai.Multiline = false;
			this.txtLoai.Name = "txtLoai";
			this.txtLoai.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtLoai.PasswordChar = false;
			this.txtLoai.Size = new System.Drawing.Size(261, 36);
			this.txtLoai.TabIndex = 94;
			this.txtLoai.Texts = "";
			this.txtLoai.UnderlinedStyle = false;
			// 
			// txtMaXe
			// 
			this.txtMaXe.BackColor = System.Drawing.SystemColors.Window;
			this.txtMaXe.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtMaXe.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtMaXe.BorderSize = 2;
			this.txtMaXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtMaXe.ForeColor = System.Drawing.Color.Black;
			this.txtMaXe.Location = new System.Drawing.Point(146, 73);
			this.txtMaXe.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtMaXe.Multiline = false;
			this.txtMaXe.Name = "txtMaXe";
			this.txtMaXe.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtMaXe.PasswordChar = false;
			this.txtMaXe.Size = new System.Drawing.Size(261, 36);
			this.txtMaXe.TabIndex = 93;
			this.txtMaXe.Texts = "";
			this.txtMaXe.UnderlinedStyle = false;
			// 
			// txtNhanHieu
			// 
			this.txtNhanHieu.BackColor = System.Drawing.SystemColors.Window;
			this.txtNhanHieu.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtNhanHieu.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtNhanHieu.BorderSize = 2;
			this.txtNhanHieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtNhanHieu.ForeColor = System.Drawing.Color.Black;
			this.txtNhanHieu.Location = new System.Drawing.Point(146, 129);
			this.txtNhanHieu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtNhanHieu.Multiline = false;
			this.txtNhanHieu.Name = "txtNhanHieu";
			this.txtNhanHieu.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtNhanHieu.PasswordChar = false;
			this.txtNhanHieu.Size = new System.Drawing.Size(261, 36);
			this.txtNhanHieu.TabIndex = 92;
			this.txtNhanHieu.Texts = "";
			this.txtNhanHieu.UnderlinedStyle = false;
			// 
			// btnEdit
			// 
			this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(144)))));
			this.btnEdit.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(144)))));
			this.btnEdit.BorderColor = System.Drawing.Color.Black;
			this.btnEdit.BorderRadius = 18;
			this.btnEdit.BorderSize = 1;
			this.btnEdit.FlatAppearance.BorderSize = 0;
			this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEdit.ForeColor = System.Drawing.Color.Black;
			this.btnEdit.Location = new System.Drawing.Point(539, 401);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(164, 45);
			this.btnEdit.TabIndex = 91;
			this.btnEdit.Text = "Chỉnh Sửa";
			this.btnEdit.TextColor = System.Drawing.Color.Black;
			this.btnEdit.UseVisualStyleBackColor = false;
			this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(95)))), ((int)(((byte)(92)))));
			this.btnCancel.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(95)))), ((int)(((byte)(92)))));
			this.btnCancel.BorderColor = System.Drawing.Color.Black;
			this.btnCancel.BorderRadius = 18;
			this.btnCancel.BorderSize = 1;
			this.btnCancel.FlatAppearance.BorderSize = 0;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCancel.ForeColor = System.Drawing.Color.Black;
			this.btnCancel.Location = new System.Drawing.Point(272, 401);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(164, 45);
			this.btnCancel.TabIndex = 90;
			this.btnCancel.Text = "Hủy";
			this.btnCancel.TextColor = System.Drawing.Color.Black;
			this.btnCancel.UseVisualStyleBackColor = false;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// lb_AddNhanHieu
			// 
			this.lb_AddNhanHieu.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lb_AddNhanHieu.AutoSize = true;
			this.lb_AddNhanHieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_AddNhanHieu.ForeColor = System.Drawing.Color.Black;
			this.lb_AddNhanHieu.Location = new System.Drawing.Point(46, 146);
			this.lb_AddNhanHieu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lb_AddNhanHieu.Name = "lb_AddNhanHieu";
			this.lb_AddNhanHieu.Size = new System.Drawing.Size(71, 16);
			this.lb_AddNhanHieu.TabIndex = 89;
			this.lb_AddNhanHieu.Text = "Nhãn hiệu:";
			// 
			// lb_AddSoLg
			// 
			this.lb_AddSoLg.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lb_AddSoLg.AutoSize = true;
			this.lb_AddSoLg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_AddSoLg.ForeColor = System.Drawing.Color.Black;
			this.lb_AddSoLg.Location = new System.Drawing.Point(534, 257);
			this.lb_AddSoLg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lb_AddSoLg.Name = "lb_AddSoLg";
			this.lb_AddSoLg.Size = new System.Drawing.Size(64, 16);
			this.lb_AddSoLg.TabIndex = 88;
			this.lb_AddSoLg.Text = "Số lượng:";
			// 
			// lb_AddCost
			// 
			this.lb_AddCost.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lb_AddCost.AutoSize = true;
			this.lb_AddCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_AddCost.ForeColor = System.Drawing.Color.Black;
			this.lb_AddCost.Location = new System.Drawing.Point(534, 202);
			this.lb_AddCost.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lb_AddCost.Name = "lb_AddCost";
			this.lb_AddCost.Size = new System.Drawing.Size(32, 16);
			this.lb_AddCost.TabIndex = 87;
			this.lb_AddCost.Text = "Giá:";
			// 
			// lb_AddColor
			// 
			this.lb_AddColor.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lb_AddColor.AutoSize = true;
			this.lb_AddColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_AddColor.ForeColor = System.Drawing.Color.Black;
			this.lb_AddColor.Location = new System.Drawing.Point(46, 202);
			this.lb_AddColor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lb_AddColor.Name = "lb_AddColor";
			this.lb_AddColor.Size = new System.Drawing.Size(62, 16);
			this.lb_AddColor.TabIndex = 86;
			this.lb_AddColor.Text = "Màu sắc:";
			// 
			// lb_AddLoai
			// 
			this.lb_AddLoai.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lb_AddLoai.AutoSize = true;
			this.lb_AddLoai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_AddLoai.ForeColor = System.Drawing.Color.Black;
			this.lb_AddLoai.Location = new System.Drawing.Point(46, 258);
			this.lb_AddLoai.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lb_AddLoai.Name = "lb_AddLoai";
			this.lb_AddLoai.Size = new System.Drawing.Size(37, 16);
			this.lb_AddLoai.TabIndex = 85;
			this.lb_AddLoai.Text = "Loại:";
			// 
			// lb_AddSoGhe
			// 
			this.lb_AddSoGhe.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lb_AddSoGhe.AutoSize = true;
			this.lb_AddSoGhe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_AddSoGhe.ForeColor = System.Drawing.Color.Black;
			this.lb_AddSoGhe.Location = new System.Drawing.Point(534, 146);
			this.lb_AddSoGhe.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lb_AddSoGhe.Name = "lb_AddSoGhe";
			this.lb_AddSoGhe.Size = new System.Drawing.Size(54, 16);
			this.lb_AddSoGhe.TabIndex = 84;
			this.lb_AddSoGhe.Text = "Số ghế:";
			// 
			// lb_AddYear
			// 
			this.lb_AddYear.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lb_AddYear.AutoSize = true;
			this.lb_AddYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_AddYear.ForeColor = System.Drawing.Color.Black;
			this.lb_AddYear.Location = new System.Drawing.Point(534, 91);
			this.lb_AddYear.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lb_AddYear.Name = "lb_AddYear";
			this.lb_AddYear.Size = new System.Drawing.Size(96, 16);
			this.lb_AddYear.TabIndex = 83;
			this.lb_AddYear.Text = "Năm Sản Xuất:";
			// 
			// lb_AddMaXe
			// 
			this.lb_AddMaXe.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lb_AddMaXe.AutoSize = true;
			this.lb_AddMaXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_AddMaXe.ForeColor = System.Drawing.Color.Black;
			this.lb_AddMaXe.Location = new System.Drawing.Point(46, 90);
			this.lb_AddMaXe.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lb_AddMaXe.Name = "lb_AddMaXe";
			this.lb_AddMaXe.Size = new System.Drawing.Size(47, 16);
			this.lb_AddMaXe.TabIndex = 82;
			this.lb_AddMaXe.Text = "Mã xe:";
			// 
			// EditCarForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(243)))), ((int)(((byte)(251)))));
			this.ClientSize = new System.Drawing.Size(974, 542);
			this.Controls.Add(this.txtGia);
			this.Controls.Add(this.txtSoLg);
			this.Controls.Add(this.txtNamSX);
			this.Controls.Add(this.txtSoGhe);
			this.Controls.Add(this.txtMauSac);
			this.Controls.Add(this.txtLoai);
			this.Controls.Add(this.txtMaXe);
			this.Controls.Add(this.txtNhanHieu);
			this.Controls.Add(this.btnEdit);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.lb_AddNhanHieu);
			this.Controls.Add(this.lb_AddSoLg);
			this.Controls.Add(this.lb_AddCost);
			this.Controls.Add(this.lb_AddColor);
			this.Controls.Add(this.lb_AddLoai);
			this.Controls.Add(this.lb_AddSoGhe);
			this.Controls.Add(this.lb_AddYear);
			this.Controls.Add(this.lb_AddMaXe);
			this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.Name = "EditCarForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "EditCarForm";
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        public TextBoxDesign txtGia;
        public TextBoxDesign txtSoLg;
        public TextBoxDesign txtNamSX;
        public TextBoxDesign txtSoGhe;
        public TextBoxDesign txtMauSac;
        public TextBoxDesign txtLoai;
        public TextBoxDesign txtMaXe;
        public TextBoxDesign txtNhanHieu;
        private ButtonDesign btnEdit;
        private ButtonDesign btnCancel;
        private System.Windows.Forms.Label lb_AddNhanHieu;
        private System.Windows.Forms.Label lb_AddSoLg;
        private System.Windows.Forms.Label lb_AddCost;
        private System.Windows.Forms.Label lb_AddColor;
        private System.Windows.Forms.Label lb_AddLoai;
        private System.Windows.Forms.Label lb_AddSoGhe;
        private System.Windows.Forms.Label lb_AddYear;
        private System.Windows.Forms.Label lb_AddMaXe;
    }
}