﻿
namespace QuanLyShowRoomOto
{
    partial class AddSingleDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.lbTimKiem = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtMaDon = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtSoLg = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtGiaNhap = new QuanLyShowRoomOto.TextBoxDesign();
			this.comboBoxMaXe = new System.Windows.Forms.ComboBox();
			this.btnAdd = new QuanLyShowRoomOto.ButtonDesign();
			this.btnCancel = new QuanLyShowRoomOto.ButtonDesign();
			this.SuspendLayout();
			// 
			// lbTimKiem
			// 
			this.lbTimKiem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lbTimKiem.AutoSize = true;
			this.lbTimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTimKiem.ForeColor = System.Drawing.Color.Black;
			this.lbTimKiem.Location = new System.Drawing.Point(27, 39);
			this.lbTimKiem.Name = "lbTimKiem";
			this.lbTimKiem.Size = new System.Drawing.Size(57, 16);
			this.lbTimKiem.TabIndex = 66;
			this.lbTimKiem.Text = "Mã Đơn:";
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Black;
			this.label1.Location = new System.Drawing.Point(29, 99);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(49, 16);
			this.label1.TabIndex = 67;
			this.label1.Text = "Mã Xe:";
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Black;
			this.label2.Location = new System.Drawing.Point(27, 159);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(68, 16);
			this.label2.TabIndex = 68;
			this.label2.Text = "Số Lượng:";
			// 
			// label3
			// 
			this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.Black;
			this.label3.Location = new System.Drawing.Point(27, 219);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(68, 16);
			this.label3.TabIndex = 69;
			this.label3.Text = "Giá Nhập:";
			// 
			// txtMaDon
			// 
			this.txtMaDon.BackColor = System.Drawing.SystemColors.Window;
			this.txtMaDon.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtMaDon.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtMaDon.BorderSize = 2;
			this.txtMaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtMaDon.ForeColor = System.Drawing.Color.Black;
			this.txtMaDon.Location = new System.Drawing.Point(116, 31);
			this.txtMaDon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtMaDon.Multiline = false;
			this.txtMaDon.Name = "txtMaDon";
			this.txtMaDon.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtMaDon.PasswordChar = false;
			this.txtMaDon.Size = new System.Drawing.Size(143, 36);
			this.txtMaDon.TabIndex = 70;
			this.txtMaDon.Texts = "";
			this.txtMaDon.UnderlinedStyle = false;
			// 
			// txtSoLg
			// 
			this.txtSoLg.BackColor = System.Drawing.SystemColors.Window;
			this.txtSoLg.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtSoLg.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtSoLg.BorderSize = 2;
			this.txtSoLg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtSoLg.ForeColor = System.Drawing.Color.Black;
			this.txtSoLg.Location = new System.Drawing.Point(116, 147);
			this.txtSoLg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtSoLg.Multiline = false;
			this.txtSoLg.Name = "txtSoLg";
			this.txtSoLg.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtSoLg.PasswordChar = false;
			this.txtSoLg.Size = new System.Drawing.Size(143, 36);
			this.txtSoLg.TabIndex = 71;
			this.txtSoLg.Texts = "";
			this.txtSoLg.UnderlinedStyle = false;
			// 
			// txtGiaNhap
			// 
			this.txtGiaNhap.BackColor = System.Drawing.SystemColors.Window;
			this.txtGiaNhap.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtGiaNhap.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtGiaNhap.BorderSize = 2;
			this.txtGiaNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtGiaNhap.ForeColor = System.Drawing.Color.Black;
			this.txtGiaNhap.Location = new System.Drawing.Point(116, 209);
			this.txtGiaNhap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtGiaNhap.Multiline = false;
			this.txtGiaNhap.Name = "txtGiaNhap";
			this.txtGiaNhap.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtGiaNhap.PasswordChar = false;
			this.txtGiaNhap.Size = new System.Drawing.Size(143, 36);
			this.txtGiaNhap.TabIndex = 72;
			this.txtGiaNhap.Texts = "";
			this.txtGiaNhap.UnderlinedStyle = false;
			// 
			// comboBoxMaXe
			// 
			this.comboBoxMaXe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxMaXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.comboBoxMaXe.ForeColor = System.Drawing.Color.Black;
			this.comboBoxMaXe.FormattingEnabled = true;
			this.comboBoxMaXe.Location = new System.Drawing.Point(116, 94);
			this.comboBoxMaXe.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.comboBoxMaXe.Name = "comboBoxMaXe";
			this.comboBoxMaXe.Size = new System.Drawing.Size(145, 24);
			this.comboBoxMaXe.TabIndex = 73;
			// 
			// btnAdd
			// 
			this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(144)))));
			this.btnAdd.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(144)))));
			this.btnAdd.BorderColor = System.Drawing.Color.Black;
			this.btnAdd.BorderRadius = 18;
			this.btnAdd.BorderSize = 1;
			this.btnAdd.FlatAppearance.BorderSize = 0;
			this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAdd.ForeColor = System.Drawing.Color.Black;
			this.btnAdd.Location = new System.Drawing.Point(34, 320);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(109, 40);
			this.btnAdd.TabIndex = 74;
			this.btnAdd.Text = "Thêm ";
			this.btnAdd.TextColor = System.Drawing.Color.Black;
			this.btnAdd.UseVisualStyleBackColor = false;
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(95)))), ((int)(((byte)(92)))));
			this.btnCancel.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(95)))), ((int)(((byte)(92)))));
			this.btnCancel.BorderColor = System.Drawing.Color.Black;
			this.btnCancel.BorderRadius = 18;
			this.btnCancel.BorderSize = 1;
			this.btnCancel.FlatAppearance.BorderSize = 0;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCancel.ForeColor = System.Drawing.Color.Black;
			this.btnCancel.Location = new System.Drawing.Point(165, 320);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(109, 40);
			this.btnCancel.TabIndex = 75;
			this.btnCancel.Text = "Thoát";
			this.btnCancel.TextColor = System.Drawing.Color.Black;
			this.btnCancel.UseVisualStyleBackColor = false;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// AddSingleDetailForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(243)))), ((int)(((byte)(251)))));
			this.ClientSize = new System.Drawing.Size(308, 399);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.comboBoxMaXe);
			this.Controls.Add(this.txtGiaNhap);
			this.Controls.Add(this.txtSoLg);
			this.Controls.Add(this.txtMaDon);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lbTimKiem);
			this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.Name = "AddSingleDetailForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "AddSingleDetailForm";
			this.Load += new System.EventHandler(this.AddSingleDetailForm_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbTimKiem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public TextBoxDesign txtMaDon;
        private TextBoxDesign txtSoLg;
        private TextBoxDesign txtGiaNhap;
        private System.Windows.Forms.ComboBox comboBoxMaXe;
        private ButtonDesign btnAdd;
        private ButtonDesign btnCancel;
    }
}