﻿
namespace QuanLyShowRoomOto
{
    partial class EditSingleDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnCancel = new QuanLyShowRoomOto.ButtonDesign();
			this.btnEdit = new QuanLyShowRoomOto.ButtonDesign();
			this.txtGiaNhap = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtSoLg = new QuanLyShowRoomOto.TextBoxDesign();
			this.txtMaDon = new QuanLyShowRoomOto.TextBoxDesign();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.lbTimKiem = new System.Windows.Forms.Label();
			this.txtMaXe = new QuanLyShowRoomOto.TextBoxDesign();
			this.SuspendLayout();
			// 
			// btnCancel
			// 
			this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(95)))), ((int)(((byte)(92)))));
			this.btnCancel.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(95)))), ((int)(((byte)(92)))));
			this.btnCancel.BorderColor = System.Drawing.Color.Black;
			this.btnCancel.BorderRadius = 18;
			this.btnCancel.BorderSize = 1;
			this.btnCancel.FlatAppearance.BorderSize = 0;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCancel.ForeColor = System.Drawing.Color.Black;
			this.btnCancel.Location = new System.Drawing.Point(183, 302);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(109, 40);
			this.btnCancel.TabIndex = 85;
			this.btnCancel.Text = "Thoát";
			this.btnCancel.TextColor = System.Drawing.Color.Black;
			this.btnCancel.UseVisualStyleBackColor = false;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnEdit
			// 
			this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
			this.btnEdit.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
			this.btnEdit.BorderColor = System.Drawing.Color.Black;
			this.btnEdit.BorderRadius = 18;
			this.btnEdit.BorderSize = 1;
			this.btnEdit.FlatAppearance.BorderSize = 0;
			this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEdit.ForeColor = System.Drawing.Color.Black;
			this.btnEdit.Location = new System.Drawing.Point(40, 302);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(109, 40);
			this.btnEdit.TabIndex = 84;
			this.btnEdit.Text = "Chỉnh Sửa";
			this.btnEdit.TextColor = System.Drawing.Color.Black;
			this.btnEdit.UseVisualStyleBackColor = false;
			this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
			// 
			// txtGiaNhap
			// 
			this.txtGiaNhap.BackColor = System.Drawing.SystemColors.Window;
			this.txtGiaNhap.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtGiaNhap.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtGiaNhap.BorderSize = 2;
			this.txtGiaNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtGiaNhap.ForeColor = System.Drawing.Color.Black;
			this.txtGiaNhap.Location = new System.Drawing.Point(135, 209);
			this.txtGiaNhap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtGiaNhap.Multiline = false;
			this.txtGiaNhap.Name = "txtGiaNhap";
			this.txtGiaNhap.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtGiaNhap.PasswordChar = false;
			this.txtGiaNhap.Size = new System.Drawing.Size(143, 36);
			this.txtGiaNhap.TabIndex = 82;
			this.txtGiaNhap.Texts = "";
			this.txtGiaNhap.UnderlinedStyle = false;
			// 
			// txtSoLg
			// 
			this.txtSoLg.BackColor = System.Drawing.SystemColors.Window;
			this.txtSoLg.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtSoLg.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtSoLg.BorderSize = 2;
			this.txtSoLg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtSoLg.ForeColor = System.Drawing.Color.Black;
			this.txtSoLg.Location = new System.Drawing.Point(135, 150);
			this.txtSoLg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtSoLg.Multiline = false;
			this.txtSoLg.Name = "txtSoLg";
			this.txtSoLg.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtSoLg.PasswordChar = false;
			this.txtSoLg.Size = new System.Drawing.Size(143, 36);
			this.txtSoLg.TabIndex = 81;
			this.txtSoLg.Texts = "";
			this.txtSoLg.UnderlinedStyle = false;
			// 
			// txtMaDon
			// 
			this.txtMaDon.BackColor = System.Drawing.SystemColors.Window;
			this.txtMaDon.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtMaDon.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtMaDon.BorderSize = 2;
			this.txtMaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtMaDon.ForeColor = System.Drawing.Color.Black;
			this.txtMaDon.Location = new System.Drawing.Point(136, 31);
			this.txtMaDon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtMaDon.Multiline = false;
			this.txtMaDon.Name = "txtMaDon";
			this.txtMaDon.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtMaDon.PasswordChar = false;
			this.txtMaDon.Size = new System.Drawing.Size(143, 36);
			this.txtMaDon.TabIndex = 80;
			this.txtMaDon.Texts = "";
			this.txtMaDon.UnderlinedStyle = false;
			// 
			// label3
			// 
			this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.Black;
			this.label3.Location = new System.Drawing.Point(44, 219);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(68, 16);
			this.label3.TabIndex = 79;
			this.label3.Text = "Giá Nhập:";
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Black;
			this.label2.Location = new System.Drawing.Point(44, 160);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(68, 16);
			this.label2.TabIndex = 78;
			this.label2.Text = "Số Lượng:";
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Black;
			this.label1.Location = new System.Drawing.Point(46, 101);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(49, 16);
			this.label1.TabIndex = 77;
			this.label1.Text = "Mã Xe:";
			// 
			// lbTimKiem
			// 
			this.lbTimKiem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lbTimKiem.AutoSize = true;
			this.lbTimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTimKiem.ForeColor = System.Drawing.Color.Black;
			this.lbTimKiem.Location = new System.Drawing.Point(44, 41);
			this.lbTimKiem.Name = "lbTimKiem";
			this.lbTimKiem.Size = new System.Drawing.Size(57, 16);
			this.lbTimKiem.TabIndex = 76;
			this.lbTimKiem.Text = "Mã Đơn:";
			// 
			// txtMaXe
			// 
			this.txtMaXe.BackColor = System.Drawing.SystemColors.Window;
			this.txtMaXe.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
			this.txtMaXe.BorderFocusColor = System.Drawing.Color.HotPink;
			this.txtMaXe.BorderSize = 2;
			this.txtMaXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtMaXe.ForeColor = System.Drawing.Color.Black;
			this.txtMaXe.Location = new System.Drawing.Point(135, 90);
			this.txtMaXe.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.txtMaXe.Multiline = false;
			this.txtMaXe.Name = "txtMaXe";
			this.txtMaXe.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
			this.txtMaXe.PasswordChar = false;
			this.txtMaXe.Size = new System.Drawing.Size(143, 36);
			this.txtMaXe.TabIndex = 86;
			this.txtMaXe.Texts = "";
			this.txtMaXe.UnderlinedStyle = false;
			// 
			// EditSingleDetailForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(243)))), ((int)(((byte)(251)))));
			this.ClientSize = new System.Drawing.Size(332, 395);
			this.Controls.Add(this.txtMaXe);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnEdit);
			this.Controls.Add(this.txtGiaNhap);
			this.Controls.Add(this.txtSoLg);
			this.Controls.Add(this.txtMaDon);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lbTimKiem);
			this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.Name = "EditSingleDetailForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "EditSingleDetailForm";
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private ButtonDesign btnCancel;
        private ButtonDesign btnEdit;
        public TextBoxDesign txtGiaNhap;
        public TextBoxDesign txtSoLg;
        public TextBoxDesign txtMaDon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbTimKiem;
        public TextBoxDesign txtMaXe;
    }
}