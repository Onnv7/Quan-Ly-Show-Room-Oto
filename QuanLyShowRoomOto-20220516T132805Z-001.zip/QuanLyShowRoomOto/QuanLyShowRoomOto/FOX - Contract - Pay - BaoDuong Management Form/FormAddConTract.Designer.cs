﻿
namespace QuanLyShowRoomOto
{
    partial class FormAddConTract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_AddMaXe = new System.Windows.Forms.Label();
            this.comboBoxMaXe = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_Recieve = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_Sign = new System.Windows.Forms.DateTimePicker();
            this.txtMaHD = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtThue = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtSumCost = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtMaKH = new QuanLyShowRoomOto.TextBoxDesign();
            this.btnAdd = new QuanLyShowRoomOto.ButtonDesign();
            this.btnCancel = new QuanLyShowRoomOto.ButtonDesign();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButtonDesign3 = new QuanLyShowRoomOto.RadioButtonDesign();
            this.radioButtonDesign2 = new QuanLyShowRoomOto.RadioButtonDesign();
            this.radioButtonDesign1 = new QuanLyShowRoomOto.RadioButtonDesign();
            this.lb_HanChot = new System.Windows.Forms.Label();
            this.txt_timePay1 = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtTongTien1 = new QuanLyShowRoomOto.TextBoxDesign();
            this.lb_TongTien = new System.Windows.Forms.Label();
            this.lb_TimePay = new System.Windows.Forms.Label();
            this.txtPayMoney1 = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtMaGD1 = new QuanLyShowRoomOto.TextBoxDesign();
            this.lb_MoneyGD = new System.Windows.Forms.Label();
            this.dateTimePicker_HanChot1 = new System.Windows.Forms.DateTimePicker();
            this.panelGD1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panelGD2 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_timePay2 = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtTongTien2 = new QuanLyShowRoomOto.TextBoxDesign();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtPayMoney2 = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtMaGD2 = new QuanLyShowRoomOto.TextBoxDesign();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dateTimePicker_HanChot2 = new System.Windows.Forms.DateTimePicker();
            this.panelGD3 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_timePay3 = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtTongTien3 = new QuanLyShowRoomOto.TextBoxDesign();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtPayMoney3 = new QuanLyShowRoomOto.TextBoxDesign();
            this.txtMaGD3 = new QuanLyShowRoomOto.TextBoxDesign();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.dateTimePicker_HanChot3 = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.panelGD1.SuspendLayout();
            this.panelGD2.SuspendLayout();
            this.panelGD3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(37, 106);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 16);
            this.label7.TabIndex = 60;
            this.label7.Text = "Ngày Ký:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(455, 153);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 16);
            this.label6.TabIndex = 59;
            this.label6.Text = "Mã KH:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(455, 100);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 16);
            this.label5.TabIndex = 58;
            this.label5.Text = "Mã xe:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(455, 198);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 16);
            this.label4.TabIndex = 57;
            this.label4.Text = "Số Lần Thanh Toán:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(455, 55);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 16);
            this.label3.TabIndex = 56;
            this.label3.Text = "Tổng Chi Phí:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(37, 209);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 16);
            this.label2.TabIndex = 55;
            this.label2.Text = "Thuế:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(37, 163);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 16);
            this.label1.TabIndex = 54;
            this.label1.Text = "Ngày Nhận Xe:";
            // 
            // lb_AddMaXe
            // 
            this.lb_AddMaXe.AutoSize = true;
            this.lb_AddMaXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_AddMaXe.ForeColor = System.Drawing.Color.Black;
            this.lb_AddMaXe.Location = new System.Drawing.Point(37, 51);
            this.lb_AddMaXe.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_AddMaXe.Name = "lb_AddMaXe";
            this.lb_AddMaXe.Size = new System.Drawing.Size(53, 16);
            this.lb_AddMaXe.TabIndex = 53;
            this.lb_AddMaXe.Text = "Mã HD:";
            // 
            // comboBoxMaXe
            // 
            this.comboBoxMaXe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMaXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMaXe.FormattingEnabled = true;
            this.comboBoxMaXe.Location = new System.Drawing.Point(615, 100);
            this.comboBoxMaXe.Name = "comboBoxMaXe";
            this.comboBoxMaXe.Size = new System.Drawing.Size(261, 24);
            this.comboBoxMaXe.TabIndex = 51;
            this.comboBoxMaXe.SelectedIndexChanged += new System.EventHandler(this.comboBoxMaXe_SelectedIndexChanged);
            // 
            // dateTimePicker_Recieve
            // 
            this.dateTimePicker_Recieve.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_Recieve.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_Recieve.Location = new System.Drawing.Point(151, 159);
            this.dateTimePicker_Recieve.Name = "dateTimePicker_Recieve";
            this.dateTimePicker_Recieve.Size = new System.Drawing.Size(220, 22);
            this.dateTimePicker_Recieve.TabIndex = 50;
            this.dateTimePicker_Recieve.Value = new System.DateTime(2022, 4, 20, 0, 0, 0, 0);
            // 
            // dateTimePicker_Sign
            // 
            this.dateTimePicker_Sign.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_Sign.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_Sign.Location = new System.Drawing.Point(151, 100);
            this.dateTimePicker_Sign.Name = "dateTimePicker_Sign";
            this.dateTimePicker_Sign.Size = new System.Drawing.Size(220, 22);
            this.dateTimePicker_Sign.TabIndex = 49;
            this.dateTimePicker_Sign.Value = new System.DateTime(2022, 4, 20, 0, 0, 0, 0);
            // 
            // txtMaHD
            // 
            this.txtMaHD.BackColor = System.Drawing.SystemColors.Window;
            this.txtMaHD.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtMaHD.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtMaHD.BorderSize = 2;
            this.txtMaHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaHD.ForeColor = System.Drawing.Color.DimGray;
            this.txtMaHD.Location = new System.Drawing.Point(151, 41);
            this.txtMaHD.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaHD.Multiline = false;
            this.txtMaHD.Name = "txtMaHD";
            this.txtMaHD.Padding = new System.Windows.Forms.Padding(7);
            this.txtMaHD.PasswordChar = false;
            this.txtMaHD.Size = new System.Drawing.Size(261, 36);
            this.txtMaHD.TabIndex = 80;
            this.txtMaHD.Texts = "";
            this.txtMaHD.UnderlinedStyle = false;
            // 
            // txtThue
            // 
            this.txtThue.BackColor = System.Drawing.SystemColors.Window;
            this.txtThue.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtThue.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtThue.BorderSize = 2;
            this.txtThue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThue.ForeColor = System.Drawing.Color.DimGray;
            this.txtThue.Location = new System.Drawing.Point(151, 199);
            this.txtThue.Margin = new System.Windows.Forms.Padding(4);
            this.txtThue.Multiline = false;
            this.txtThue.Name = "txtThue";
            this.txtThue.Padding = new System.Windows.Forms.Padding(7);
            this.txtThue.PasswordChar = false;
            this.txtThue.Size = new System.Drawing.Size(261, 36);
            this.txtThue.TabIndex = 81;
            this.txtThue.Texts = "";
            this.txtThue.UnderlinedStyle = false;
            this.txtThue.Leave += new System.EventHandler(this.txtThue_Leave);
            // 
            // txtSumCost
            // 
            this.txtSumCost.BackColor = System.Drawing.SystemColors.Window;
            this.txtSumCost.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtSumCost.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtSumCost.BorderSize = 2;
            this.txtSumCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSumCost.ForeColor = System.Drawing.Color.DimGray;
            this.txtSumCost.Location = new System.Drawing.Point(615, 41);
            this.txtSumCost.Margin = new System.Windows.Forms.Padding(4);
            this.txtSumCost.Multiline = false;
            this.txtSumCost.Name = "txtSumCost";
            this.txtSumCost.Padding = new System.Windows.Forms.Padding(7);
            this.txtSumCost.PasswordChar = false;
            this.txtSumCost.Size = new System.Drawing.Size(261, 36);
            this.txtSumCost.TabIndex = 82;
            this.txtSumCost.Texts = "";
            this.txtSumCost.UnderlinedStyle = false;
            // 
            // txtMaKH
            // 
            this.txtMaKH.BackColor = System.Drawing.SystemColors.Window;
            this.txtMaKH.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtMaKH.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtMaKH.BorderSize = 2;
            this.txtMaKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaKH.ForeColor = System.Drawing.Color.DimGray;
            this.txtMaKH.Location = new System.Drawing.Point(615, 143);
            this.txtMaKH.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaKH.Multiline = false;
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Padding = new System.Windows.Forms.Padding(7);
            this.txtMaKH.PasswordChar = false;
            this.txtMaKH.Size = new System.Drawing.Size(261, 36);
            this.txtMaKH.TabIndex = 84;
            this.txtMaKH.Texts = "";
            this.txtMaKH.UnderlinedStyle = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(144)))));
            this.btnAdd.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(144)))));
            this.btnAdd.BorderColor = System.Drawing.Color.Black;
            this.btnAdd.BorderRadius = 18;
            this.btnAdd.BorderSize = 1;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.Black;
            this.btnAdd.Location = new System.Drawing.Point(974, 100);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(150, 40);
            this.btnAdd.TabIndex = 86;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.TextColor = System.Drawing.Color.Black;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(81)))), ((int)(((byte)(70)))));
            this.btnCancel.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(81)))), ((int)(((byte)(70)))));
            this.btnCancel.BorderColor = System.Drawing.Color.Black;
            this.btnCancel.BorderRadius = 18;
            this.btnCancel.BorderSize = 1;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(974, 27);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(150, 40);
            this.btnCancel.TabIndex = 85;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.TextColor = System.Drawing.Color.Black;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButtonDesign3);
            this.panel1.Controls.Add(this.radioButtonDesign2);
            this.panel1.Controls.Add(this.radioButtonDesign1);
            this.panel1.Location = new System.Drawing.Point(618, 188);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(258, 48);
            this.panel1.TabIndex = 87;
            // 
            // radioButtonDesign3
            // 
            this.radioButtonDesign3.AutoSize = true;
            this.radioButtonDesign3.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(154)))), ((int)(((byte)(197)))));
            this.radioButtonDesign3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDesign3.Location = new System.Drawing.Point(169, 15);
            this.radioButtonDesign3.MinimumSize = new System.Drawing.Size(0, 21);
            this.radioButtonDesign3.Name = "radioButtonDesign3";
            this.radioButtonDesign3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.radioButtonDesign3.Size = new System.Drawing.Size(45, 21);
            this.radioButtonDesign3.TabIndex = 2;
            this.radioButtonDesign3.TabStop = true;
            this.radioButtonDesign3.Text = "3";
            this.radioButtonDesign3.UnCheckedColor = System.Drawing.Color.Gray;
            this.radioButtonDesign3.UseVisualStyleBackColor = true;
            this.radioButtonDesign3.CheckedChanged += new System.EventHandler(this.radioButtonDesign3_CheckedChanged);
            // 
            // radioButtonDesign2
            // 
            this.radioButtonDesign2.AutoSize = true;
            this.radioButtonDesign2.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(154)))), ((int)(((byte)(197)))));
            this.radioButtonDesign2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDesign2.Location = new System.Drawing.Point(105, 15);
            this.radioButtonDesign2.MinimumSize = new System.Drawing.Size(0, 21);
            this.radioButtonDesign2.Name = "radioButtonDesign2";
            this.radioButtonDesign2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.radioButtonDesign2.Size = new System.Drawing.Size(45, 21);
            this.radioButtonDesign2.TabIndex = 1;
            this.radioButtonDesign2.TabStop = true;
            this.radioButtonDesign2.Text = "2";
            this.radioButtonDesign2.UnCheckedColor = System.Drawing.Color.Gray;
            this.radioButtonDesign2.UseVisualStyleBackColor = true;
            this.radioButtonDesign2.CheckedChanged += new System.EventHandler(this.radioButtonDesign2_CheckedChanged);
            // 
            // radioButtonDesign1
            // 
            this.radioButtonDesign1.AutoSize = true;
            this.radioButtonDesign1.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(154)))), ((int)(((byte)(197)))));
            this.radioButtonDesign1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDesign1.Location = new System.Drawing.Point(45, 15);
            this.radioButtonDesign1.MinimumSize = new System.Drawing.Size(0, 21);
            this.radioButtonDesign1.Name = "radioButtonDesign1";
            this.radioButtonDesign1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.radioButtonDesign1.Size = new System.Drawing.Size(45, 21);
            this.radioButtonDesign1.TabIndex = 0;
            this.radioButtonDesign1.TabStop = true;
            this.radioButtonDesign1.Text = "1";
            this.radioButtonDesign1.UnCheckedColor = System.Drawing.Color.Gray;
            this.radioButtonDesign1.UseVisualStyleBackColor = true;
            this.radioButtonDesign1.CheckedChanged += new System.EventHandler(this.radioButtonDesign1_CheckedChanged);
            // 
            // lb_HanChot
            // 
            this.lb_HanChot.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_HanChot.AutoSize = true;
            this.lb_HanChot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_HanChot.ForeColor = System.Drawing.Color.Black;
            this.lb_HanChot.Location = new System.Drawing.Point(33, 149);
            this.lb_HanChot.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_HanChot.Name = "lb_HanChot";
            this.lb_HanChot.Size = new System.Drawing.Size(104, 16);
            this.lb_HanChot.TabIndex = 156;
            this.lb_HanChot.Text = "Hạn Chót Đóng :";
            // 
            // txt_timePay1
            // 
            this.txt_timePay1.BackColor = System.Drawing.SystemColors.Window;
            this.txt_timePay1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txt_timePay1.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_timePay1.BorderSize = 2;
            this.txt_timePay1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_timePay1.ForeColor = System.Drawing.Color.DimGray;
            this.txt_timePay1.Location = new System.Drawing.Point(656, 86);
            this.txt_timePay1.Margin = new System.Windows.Forms.Padding(4);
            this.txt_timePay1.Multiline = false;
            this.txt_timePay1.Name = "txt_timePay1";
            this.txt_timePay1.Padding = new System.Windows.Forms.Padding(7);
            this.txt_timePay1.PasswordChar = false;
            this.txt_timePay1.Size = new System.Drawing.Size(261, 36);
            this.txt_timePay1.TabIndex = 155;
            this.txt_timePay1.Texts = "";
            this.txt_timePay1.UnderlinedStyle = false;
            // 
            // txtTongTien1
            // 
            this.txtTongTien1.BackColor = System.Drawing.SystemColors.Window;
            this.txtTongTien1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtTongTien1.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTongTien1.BorderSize = 2;
            this.txtTongTien1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongTien1.ForeColor = System.Drawing.Color.DimGray;
            this.txtTongTien1.Location = new System.Drawing.Point(656, 42);
            this.txtTongTien1.Margin = new System.Windows.Forms.Padding(4);
            this.txtTongTien1.Multiline = false;
            this.txtTongTien1.Name = "txtTongTien1";
            this.txtTongTien1.Padding = new System.Windows.Forms.Padding(7);
            this.txtTongTien1.PasswordChar = false;
            this.txtTongTien1.Size = new System.Drawing.Size(261, 36);
            this.txtTongTien1.TabIndex = 154;
            this.txtTongTien1.Texts = "";
            this.txtTongTien1.UnderlinedStyle = false;
            // 
            // lb_TongTien
            // 
            this.lb_TongTien.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_TongTien.AutoSize = true;
            this.lb_TongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TongTien.ForeColor = System.Drawing.Color.Black;
            this.lb_TongTien.Location = new System.Drawing.Point(501, 53);
            this.lb_TongTien.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_TongTien.Name = "lb_TongTien";
            this.lb_TongTien.Size = new System.Drawing.Size(73, 16);
            this.lb_TongTien.TabIndex = 153;
            this.lb_TongTien.Text = "Tổng Tiền:";
            // 
            // lb_TimePay
            // 
            this.lb_TimePay.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_TimePay.AutoSize = true;
            this.lb_TimePay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TimePay.ForeColor = System.Drawing.Color.Black;
            this.lb_TimePay.Location = new System.Drawing.Point(501, 99);
            this.lb_TimePay.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_TimePay.Name = "lb_TimePay";
            this.lb_TimePay.Size = new System.Drawing.Size(129, 16);
            this.lb_TimePay.TabIndex = 152;
            this.lb_TimePay.Text = "Số Lần Thanh Toán:";
            // 
            // txtPayMoney1
            // 
            this.txtPayMoney1.BackColor = System.Drawing.SystemColors.Window;
            this.txtPayMoney1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtPayMoney1.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPayMoney1.BorderSize = 2;
            this.txtPayMoney1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayMoney1.ForeColor = System.Drawing.Color.DimGray;
            this.txtPayMoney1.Location = new System.Drawing.Point(157, 86);
            this.txtPayMoney1.Margin = new System.Windows.Forms.Padding(4);
            this.txtPayMoney1.Multiline = false;
            this.txtPayMoney1.Name = "txtPayMoney1";
            this.txtPayMoney1.Padding = new System.Windows.Forms.Padding(7);
            this.txtPayMoney1.PasswordChar = false;
            this.txtPayMoney1.Size = new System.Drawing.Size(261, 36);
            this.txtPayMoney1.TabIndex = 151;
            this.txtPayMoney1.Texts = "";
            this.txtPayMoney1.UnderlinedStyle = false;
            this.txtPayMoney1.Leave += new System.EventHandler(this.txtPayMoney1_Leave);
            // 
            // txtMaGD1
            // 
            this.txtMaGD1.BackColor = System.Drawing.SystemColors.Window;
            this.txtMaGD1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtMaGD1.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtMaGD1.BorderSize = 2;
            this.txtMaGD1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaGD1.ForeColor = System.Drawing.Color.DimGray;
            this.txtMaGD1.Location = new System.Drawing.Point(157, 42);
            this.txtMaGD1.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaGD1.Multiline = false;
            this.txtMaGD1.Name = "txtMaGD1";
            this.txtMaGD1.Padding = new System.Windows.Forms.Padding(7);
            this.txtMaGD1.PasswordChar = false;
            this.txtMaGD1.Size = new System.Drawing.Size(261, 36);
            this.txtMaGD1.TabIndex = 149;
            this.txtMaGD1.Texts = "";
            this.txtMaGD1.UnderlinedStyle = false;
            // 
            // lb_MoneyGD
            // 
            this.lb_MoneyGD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_MoneyGD.AutoSize = true;
            this.lb_MoneyGD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_MoneyGD.ForeColor = System.Drawing.Color.Black;
            this.lb_MoneyGD.Location = new System.Drawing.Point(33, 99);
            this.lb_MoneyGD.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_MoneyGD.Name = "lb_MoneyGD";
            this.lb_MoneyGD.Size = new System.Drawing.Size(81, 16);
            this.lb_MoneyGD.TabIndex = 147;
            this.lb_MoneyGD.Text = "Số Tiền GD:";
            // 
            // dateTimePicker_HanChot1
            // 
            this.dateTimePicker_HanChot1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_HanChot1.Location = new System.Drawing.Point(157, 149);
            this.dateTimePicker_HanChot1.Name = "dateTimePicker_HanChot1";
            this.dateTimePicker_HanChot1.Size = new System.Drawing.Size(181, 20);
            this.dateTimePicker_HanChot1.TabIndex = 145;
            // 
            // panelGD1
            // 
            this.panelGD1.Controls.Add(this.label8);
            this.panelGD1.Controls.Add(this.label22);
            this.panelGD1.Controls.Add(this.lb_HanChot);
            this.panelGD1.Controls.Add(this.txt_timePay1);
            this.panelGD1.Controls.Add(this.txtTongTien1);
            this.panelGD1.Controls.Add(this.lb_TongTien);
            this.panelGD1.Controls.Add(this.lb_TimePay);
            this.panelGD1.Controls.Add(this.txtPayMoney1);
            this.panelGD1.Controls.Add(this.txtMaGD1);
            this.panelGD1.Controls.Add(this.lb_MoneyGD);
            this.panelGD1.Controls.Add(this.dateTimePicker_HanChot1);
            this.panelGD1.Location = new System.Drawing.Point(12, 242);
            this.panelGD1.Name = "panelGD1";
            this.panelGD1.Size = new System.Drawing.Size(1002, 180);
            this.panelGD1.TabIndex = 157;
            this.panelGD1.Visible = false;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(33, 53);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 16);
            this.label8.TabIndex = 159;
            this.label8.Text = "Mã GD:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(15, 11);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(80, 20);
            this.label22.TabIndex = 157;
            this.label22.Text = "GD số 1:";
            // 
            // panelGD2
            // 
            this.panelGD2.Controls.Add(this.label23);
            this.panelGD2.Controls.Add(this.label10);
            this.panelGD2.Controls.Add(this.txt_timePay2);
            this.panelGD2.Controls.Add(this.txtTongTien2);
            this.panelGD2.Controls.Add(this.label11);
            this.panelGD2.Controls.Add(this.label12);
            this.panelGD2.Controls.Add(this.txtPayMoney2);
            this.panelGD2.Controls.Add(this.txtMaGD2);
            this.panelGD2.Controls.Add(this.label13);
            this.panelGD2.Controls.Add(this.label14);
            this.panelGD2.Controls.Add(this.dateTimePicker_HanChot2);
            this.panelGD2.Location = new System.Drawing.Point(12, 428);
            this.panelGD2.Name = "panelGD2";
            this.panelGD2.Size = new System.Drawing.Size(1002, 187);
            this.panelGD2.TabIndex = 158;
            this.panelGD2.Visible = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(15, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(80, 20);
            this.label23.TabIndex = 158;
            this.label23.Text = "GD số 2:";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(48, 139);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 16);
            this.label10.TabIndex = 156;
            this.label10.Text = "Hạn Chót Đóng :";
            // 
            // txt_timePay2
            // 
            this.txt_timePay2.BackColor = System.Drawing.SystemColors.Window;
            this.txt_timePay2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txt_timePay2.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_timePay2.BorderSize = 2;
            this.txt_timePay2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_timePay2.ForeColor = System.Drawing.Color.DimGray;
            this.txt_timePay2.Location = new System.Drawing.Point(651, 92);
            this.txt_timePay2.Margin = new System.Windows.Forms.Padding(4);
            this.txt_timePay2.Multiline = false;
            this.txt_timePay2.Name = "txt_timePay2";
            this.txt_timePay2.Padding = new System.Windows.Forms.Padding(7);
            this.txt_timePay2.PasswordChar = false;
            this.txt_timePay2.Size = new System.Drawing.Size(261, 36);
            this.txt_timePay2.TabIndex = 155;
            this.txt_timePay2.Texts = "";
            this.txt_timePay2.UnderlinedStyle = false;
            // 
            // txtTongTien2
            // 
            this.txtTongTien2.BackColor = System.Drawing.SystemColors.Window;
            this.txtTongTien2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtTongTien2.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTongTien2.BorderSize = 2;
            this.txtTongTien2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongTien2.ForeColor = System.Drawing.Color.DimGray;
            this.txtTongTien2.Location = new System.Drawing.Point(651, 48);
            this.txtTongTien2.Margin = new System.Windows.Forms.Padding(4);
            this.txtTongTien2.Multiline = false;
            this.txtTongTien2.Name = "txtTongTien2";
            this.txtTongTien2.Padding = new System.Windows.Forms.Padding(7);
            this.txtTongTien2.PasswordChar = false;
            this.txtTongTien2.Size = new System.Drawing.Size(261, 36);
            this.txtTongTien2.TabIndex = 154;
            this.txtTongTien2.Texts = "";
            this.txtTongTien2.UnderlinedStyle = false;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(499, 54);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 16);
            this.label11.TabIndex = 153;
            this.label11.Text = "Tổng Tiền:";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(481, 99);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(129, 16);
            this.label12.TabIndex = 152;
            this.label12.Text = "Số Lần Thanh Toán:";
            // 
            // txtPayMoney2
            // 
            this.txtPayMoney2.BackColor = System.Drawing.SystemColors.Window;
            this.txtPayMoney2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtPayMoney2.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPayMoney2.BorderSize = 2;
            this.txtPayMoney2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayMoney2.ForeColor = System.Drawing.Color.DimGray;
            this.txtPayMoney2.Location = new System.Drawing.Point(157, 92);
            this.txtPayMoney2.Margin = new System.Windows.Forms.Padding(4);
            this.txtPayMoney2.Multiline = false;
            this.txtPayMoney2.Name = "txtPayMoney2";
            this.txtPayMoney2.Padding = new System.Windows.Forms.Padding(7);
            this.txtPayMoney2.PasswordChar = false;
            this.txtPayMoney2.Size = new System.Drawing.Size(261, 36);
            this.txtPayMoney2.TabIndex = 151;
            this.txtPayMoney2.Texts = "";
            this.txtPayMoney2.UnderlinedStyle = false;
            this.txtPayMoney2._TextChanged += new System.EventHandler(this.txtPayMoney2__TextChanged);
            // 
            // txtMaGD2
            // 
            this.txtMaGD2.BackColor = System.Drawing.SystemColors.Window;
            this.txtMaGD2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtMaGD2.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtMaGD2.BorderSize = 2;
            this.txtMaGD2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaGD2.ForeColor = System.Drawing.Color.DimGray;
            this.txtMaGD2.Location = new System.Drawing.Point(157, 48);
            this.txtMaGD2.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaGD2.Multiline = false;
            this.txtMaGD2.Name = "txtMaGD2";
            this.txtMaGD2.Padding = new System.Windows.Forms.Padding(7);
            this.txtMaGD2.PasswordChar = false;
            this.txtMaGD2.Size = new System.Drawing.Size(261, 36);
            this.txtMaGD2.TabIndex = 149;
            this.txtMaGD2.Texts = "";
            this.txtMaGD2.UnderlinedStyle = false;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(48, 54);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 16);
            this.label13.TabIndex = 148;
            this.label13.Text = "Mã GD:";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(48, 99);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 16);
            this.label14.TabIndex = 147;
            this.label14.Text = "Số Tiền GD:";
            // 
            // dateTimePicker_HanChot2
            // 
            this.dateTimePicker_HanChot2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_HanChot2.Location = new System.Drawing.Point(157, 138);
            this.dateTimePicker_HanChot2.Name = "dateTimePicker_HanChot2";
            this.dateTimePicker_HanChot2.Size = new System.Drawing.Size(181, 20);
            this.dateTimePicker_HanChot2.TabIndex = 145;
            // 
            // panelGD3
            // 
            this.panelGD3.Controls.Add(this.label24);
            this.panelGD3.Controls.Add(this.label16);
            this.panelGD3.Controls.Add(this.txt_timePay3);
            this.panelGD3.Controls.Add(this.txtTongTien3);
            this.panelGD3.Controls.Add(this.label17);
            this.panelGD3.Controls.Add(this.label18);
            this.panelGD3.Controls.Add(this.txtPayMoney3);
            this.panelGD3.Controls.Add(this.txtMaGD3);
            this.panelGD3.Controls.Add(this.label19);
            this.panelGD3.Controls.Add(this.label20);
            this.panelGD3.Controls.Add(this.dateTimePicker_HanChot3);
            this.panelGD3.Location = new System.Drawing.Point(12, 621);
            this.panelGD3.Name = "panelGD3";
            this.panelGD3.Size = new System.Drawing.Size(1002, 198);
            this.panelGD3.TabIndex = 159;
            this.panelGD3.Visible = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(12, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(80, 20);
            this.label24.TabIndex = 159;
            this.label24.Text = "GD số 3:";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(48, 133);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 16);
            this.label16.TabIndex = 156;
            this.label16.Text = "Hạn Chót Đóng :";
            // 
            // txt_timePay3
            // 
            this.txt_timePay3.BackColor = System.Drawing.SystemColors.Window;
            this.txt_timePay3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txt_timePay3.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_timePay3.BorderSize = 2;
            this.txt_timePay3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_timePay3.ForeColor = System.Drawing.Color.DimGray;
            this.txt_timePay3.Location = new System.Drawing.Point(656, 81);
            this.txt_timePay3.Margin = new System.Windows.Forms.Padding(4);
            this.txt_timePay3.Multiline = false;
            this.txt_timePay3.Name = "txt_timePay3";
            this.txt_timePay3.Padding = new System.Windows.Forms.Padding(7);
            this.txt_timePay3.PasswordChar = false;
            this.txt_timePay3.Size = new System.Drawing.Size(261, 36);
            this.txt_timePay3.TabIndex = 155;
            this.txt_timePay3.Texts = "";
            this.txt_timePay3.UnderlinedStyle = false;
            // 
            // txtTongTien3
            // 
            this.txtTongTien3.BackColor = System.Drawing.SystemColors.Window;
            this.txtTongTien3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtTongTien3.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTongTien3.BorderSize = 2;
            this.txtTongTien3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongTien3.ForeColor = System.Drawing.Color.DimGray;
            this.txtTongTien3.Location = new System.Drawing.Point(656, 37);
            this.txtTongTien3.Margin = new System.Windows.Forms.Padding(4);
            this.txtTongTien3.Multiline = false;
            this.txtTongTien3.Name = "txtTongTien3";
            this.txtTongTien3.Padding = new System.Windows.Forms.Padding(7);
            this.txtTongTien3.PasswordChar = false;
            this.txtTongTien3.Size = new System.Drawing.Size(261, 36);
            this.txtTongTien3.TabIndex = 154;
            this.txtTongTien3.Texts = "";
            this.txtTongTien3.UnderlinedStyle = false;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(499, 48);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 16);
            this.label17.TabIndex = 153;
            this.label17.Text = "Tổng Tiền:";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(481, 85);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(129, 16);
            this.label18.TabIndex = 152;
            this.label18.Text = "Số Lần Thanh Toán:";
            // 
            // txtPayMoney3
            // 
            this.txtPayMoney3.BackColor = System.Drawing.SystemColors.Window;
            this.txtPayMoney3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtPayMoney3.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPayMoney3.BorderSize = 2;
            this.txtPayMoney3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayMoney3.ForeColor = System.Drawing.Color.DimGray;
            this.txtPayMoney3.Location = new System.Drawing.Point(157, 81);
            this.txtPayMoney3.Margin = new System.Windows.Forms.Padding(4);
            this.txtPayMoney3.Multiline = false;
            this.txtPayMoney3.Name = "txtPayMoney3";
            this.txtPayMoney3.Padding = new System.Windows.Forms.Padding(7);
            this.txtPayMoney3.PasswordChar = false;
            this.txtPayMoney3.Size = new System.Drawing.Size(261, 36);
            this.txtPayMoney3.TabIndex = 151;
            this.txtPayMoney3.Texts = "";
            this.txtPayMoney3.UnderlinedStyle = false;
            // 
            // txtMaGD3
            // 
            this.txtMaGD3.BackColor = System.Drawing.SystemColors.Window;
            this.txtMaGD3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(44)))), ((int)(((byte)(47)))));
            this.txtMaGD3.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtMaGD3.BorderSize = 2;
            this.txtMaGD3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaGD3.ForeColor = System.Drawing.Color.DimGray;
            this.txtMaGD3.Location = new System.Drawing.Point(157, 37);
            this.txtMaGD3.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaGD3.Multiline = false;
            this.txtMaGD3.Name = "txtMaGD3";
            this.txtMaGD3.Padding = new System.Windows.Forms.Padding(7);
            this.txtMaGD3.PasswordChar = false;
            this.txtMaGD3.Size = new System.Drawing.Size(261, 36);
            this.txtMaGD3.TabIndex = 149;
            this.txtMaGD3.Texts = "";
            this.txtMaGD3.UnderlinedStyle = false;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(48, 48);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 16);
            this.label19.TabIndex = 148;
            this.label19.Text = "Mã GD:";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(48, 85);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(81, 16);
            this.label20.TabIndex = 147;
            this.label20.Text = "Số Tiền GD:";
            // 
            // dateTimePicker_HanChot3
            // 
            this.dateTimePicker_HanChot3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_HanChot3.Location = new System.Drawing.Point(157, 132);
            this.dateTimePicker_HanChot3.Name = "dateTimePicker_HanChot3";
            this.dateTimePicker_HanChot3.Size = new System.Drawing.Size(181, 20);
            this.dateTimePicker_HanChot3.TabIndex = 145;
            // 
            // FormAddConTract
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(243)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(1083, 845);
            this.Controls.Add(this.panelGD3);
            this.Controls.Add(this.panelGD2);
            this.Controls.Add(this.panelGD1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.txtMaKH);
            this.Controls.Add(this.txtSumCost);
            this.Controls.Add(this.txtThue);
            this.Controls.Add(this.txtMaHD);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_AddMaXe);
            this.Controls.Add(this.comboBoxMaXe);
            this.Controls.Add(this.dateTimePicker_Recieve);
            this.Controls.Add(this.dateTimePicker_Sign);
            this.Name = "FormAddConTract";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddConTract";
            this.Load += new System.EventHandler(this.AddConTract_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelGD1.ResumeLayout(false);
            this.panelGD1.PerformLayout();
            this.panelGD2.ResumeLayout(false);
            this.panelGD2.PerformLayout();
            this.panelGD3.ResumeLayout(false);
            this.panelGD3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_AddMaXe;
        private System.Windows.Forms.ComboBox comboBoxMaXe;
        private System.Windows.Forms.DateTimePicker dateTimePicker_Recieve;
        private System.Windows.Forms.DateTimePicker dateTimePicker_Sign;
        public TextBoxDesign txtMaHD;
        private TextBoxDesign txtThue;
        public TextBoxDesign txtSumCost;
        public TextBoxDesign txtMaKH;
        private ButtonDesign btnAdd;
        private ButtonDesign btnCancel;
        private System.Windows.Forms.Panel panel1;
        private RadioButtonDesign radioButtonDesign3;
        private RadioButtonDesign radioButtonDesign2;
        private RadioButtonDesign radioButtonDesign1;
		private System.Windows.Forms.Label lb_HanChot;
		public TextBoxDesign txt_timePay1;
		public TextBoxDesign txtTongTien1;
		private System.Windows.Forms.Label lb_TongTien;
		private System.Windows.Forms.Label lb_TimePay;
		private TextBoxDesign txtPayMoney1;
		private TextBoxDesign txtMaGD1;
		private System.Windows.Forms.Label lb_MoneyGD;
		public System.Windows.Forms.DateTimePicker dateTimePicker_HanChot1;
		private System.Windows.Forms.Panel panelGD1;
		private System.Windows.Forms.Panel panelGD2;
		private System.Windows.Forms.Label label10;
		public TextBoxDesign txt_timePay2;
		public TextBoxDesign txtTongTien2;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private TextBoxDesign txtPayMoney2;
		private TextBoxDesign txtMaGD2;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		public System.Windows.Forms.DateTimePicker dateTimePicker_HanChot2;
		private System.Windows.Forms.Panel panelGD3;
		private System.Windows.Forms.Label label16;
		public TextBoxDesign txt_timePay3;
		public TextBoxDesign txtTongTien3;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label18;
		private TextBoxDesign txtPayMoney3;
		private TextBoxDesign txtMaGD3;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label20;
		public System.Windows.Forms.DateTimePicker dateTimePicker_HanChot3;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label8;
    }
}